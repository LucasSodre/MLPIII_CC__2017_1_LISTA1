package br.unipe.cc.mlpIII.lista1.questao4.ui;

import br.unipe.cc.mlpIII.lista1.questao4.*;

/**
 * 
 * Quest�o 04.
 * 
 * Classe main
 * 
 * @author Aleff 
 * @date 18/02/2017
 */
public class Principal 
{
	
	private static Conexao con1;

	public static void main(String[] args) 
	{
		
	//Perceba que somente tenho como usar o m�todo getInstance(), n�o tenho como criar um novo objeto Conexao;
		con1 = Conexao.getInstance();
		
		System.out.println(con1);

	}
		
}

