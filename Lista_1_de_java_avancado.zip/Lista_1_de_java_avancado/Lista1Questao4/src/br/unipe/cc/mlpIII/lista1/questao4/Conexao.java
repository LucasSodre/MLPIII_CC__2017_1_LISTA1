package br.unipe.cc.mlpIII.lista1.questao4;

/**
 * 
 * Quest�o 04.
 * 
 * Classe Conexao que n�o poder� ser instanciada uma outra vez.
 * @author Aleff 
 * @date 18/02/2017
 */


public class Conexao 
{
	
	private int numCon = 1;
	private static Conexao uniqueInstance;

	// Como o seu contrutor est� privado ela n�o poder� ser instanciada por outras classes, 
	//por�m como o metodo getInstance() � possivel verificar seus dados a partir de outros m�todos.
	private Conexao() {	}

	public static synchronized Conexao getInstance() 
	{
		if (uniqueInstance == null)
			uniqueInstance = new Conexao();

		return uniqueInstance;
	}

		public String toString() 
		{
			return "Conexao"+" "+ this.numCon;
		}
		
	}