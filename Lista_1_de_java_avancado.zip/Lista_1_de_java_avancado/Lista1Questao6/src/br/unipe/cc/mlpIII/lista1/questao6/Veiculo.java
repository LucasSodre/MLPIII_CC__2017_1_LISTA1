/*
 * Classe veiculo 
 * 
 * quest�o 06 da Lista1.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�
 * 
 */


package br.unipe.cc.mlpIII.lista1.questao6;

public class Veiculo {
	//Declara��o de Atributos percebe-se que todos est�o privados
	private String placa;
	private String marca;
	private String modelo;
	private String chassi;
	private int ano;
	private double valorKmRodado, kmInicial, kmFinal;
	private double valorLocacao;
	private Pessoa proprietario;
	
	//Contrutor que recebe todos os atributos acima como parametro e devolver com valores setados
	public Veiculo(String placa, String marca, String modelo, 
			       String chassi, int ano, double valorKmRodado, 
			       double kmInicial, double kmFinal,Pessoa proprietario)	
	{
		this.placa = (placa);
		this.marca = (marca);
		this.modelo = (modelo);
		this.chassi = (chassi);
		this.ano = (ano);
		this.valorKmRodado = (valorKmRodado);
		this.kmInicial = (kmInicial);
		this.kmFinal = (kmFinal);
		this.proprietario = proprietario;
		//Ele n�o � recebido como parametro pois seu valor depende de outros atributos
		//mas � devolvido com valor 
		this.valorLocacao = ((this.kmFinal)-(this.kmInicial)) * this.valorKmRodado; 
		
		
	}
	
	
	//metodos get de todos os atributos para que possam ser verificados depois.

	public String getPlaca() {		return placa;	}

	public String getMarca() {		return marca;	}

	public String getModelo() {		return modelo;	}

	public String getChassi() {		return chassi;	}

	public int getAno() {		return ano;	}

	public double getValorKmRodado() {		return valorKmRodado;	}
	
	public double getKmInicial() {		return kmInicial; }

	public double getKmFinal() {		return kmFinal;	}

	public double getValorLocacao() {		return valorLocacao;	}

	public Pessoa getProprietario() {		return proprietario;	}
	
	//Unico m�todo set pois caso seja necess�rio calculo desse valor em outra classe basta usar esse m�todo.
	
	public void setValorLocacao(double valorLocacao) {		this.valorLocacao = valorLocacao;	}
	
	
	//toString para quando for impresso sair bonitinho
	
	public String toString() 
	{
		return "\n\n [Veiculo]\n Placa: " + this.placa + "\n Marca: " + this.marca + "\n Modelo: " + this.modelo + "\n Chassi: " + this.chassi + 
				"\n Ano: " + this.ano + "\n Valor Por KM Rodado: R$ " + this.valorKmRodado + "\n KM Inicial : " + this.kmInicial +"\n KM Final: " + this.kmFinal + 
				"\n Valor da Loca��o: R$ " + this.valorLocacao + "\n [Propriet�rio]" + this.proprietario;
	}
	


}
