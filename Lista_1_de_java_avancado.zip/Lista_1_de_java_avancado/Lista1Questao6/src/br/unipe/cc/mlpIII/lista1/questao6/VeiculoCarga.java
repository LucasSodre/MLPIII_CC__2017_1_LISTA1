/*
 * Classe veiculoCarga Extendido da classe Veiculo
 * 
 *  
 *  quest�o 06 da Lista1.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�
 * 
 */

package br.unipe.cc.mlpIII.lista1.questao6;

public class VeiculoCarga extends Veiculo 
{
	
	//Atributo que difere a classe filha da classe pai
	private String capacidadeCarga;

	
//recebendo os atributos da classe pai como parametro do construtor
	public VeiculoCarga(String placa, String marca, String modelo, 
			            String chassi, int ano, double valorKmRodado,
			            double kmInicial, double kmFinal,
			            String capacidadeCarga, Pessoa proprietario) 
	{
		super(placa, marca, modelo, chassi, ano, valorKmRodado, kmInicial, kmFinal, proprietario);
		this.capacidadeCarga = capacidadeCarga;
	}
	
	
	//m�todo get do parametro exclusivo da classe filha
	public String getCapacidadeCarga(){		return capacidadeCarga;	}
	
	//Como se trata da classe filha para mexer nos atributos da classe pai necess�rio utilizar metodos get.
	public String toString() 
	{
		return "\n\n [Veiculo Carga]\n Placa: " + this.getPlaca() + "\n Marca: " + this.getMarca() + "\n Modelo: " + this.getModelo() + "\n Chassi: " + this.getChassi() + 
		"\n Ano: " + this.getAno() + "\n Valor Por KM Rodado: R$ " + (this.getValorKmRodado()) + "\n KM Inicial : " + this.getKmInicial() +"\n KM Final: " + this.getKmFinal() + 
		"\n Valor da Loca��o: R$ " + this.getValorLocacao() +"\n Capacidade de Carga: " + this.capacidadeCarga +"\n [Propriet�rio]" + this.getProprietario();
	}
}


