/*
 * Classe veiculoPasseio Extendido da classe Veiculo
 * 
 *  
 *  quest�o 06 da Lista1.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�
 * 
 */



package br.unipe.cc.mlpIII.lista1.questao6;

public class VeiculoPasseio extends Veiculo {
	
	//atributos da classe
	private boolean arCondicionado;
	private int qtdPortas;
	
	//Construtor da classe 
	public VeiculoPasseio(String placa, String marca, String modelo, String chassi, 
			              int ano, double valorKmRodado, double kmInicial, double kmFinal, 
			              int qtdPortas, boolean arCondicionado, Pessoa proprietario) 
	{
		super(placa, marca, modelo, chassi, ano, valorKmRodado, kmInicial, kmFinal, proprietario);
		this.arCondicionado = arCondicionado;
		this.qtdPortas = qtdPortas;
	}
	
	//Metodos get da classe n�o necess�rio set.

	public int getQtdPortas() {		return qtdPortas;	}

	public boolean isArCondicionado() {		return arCondicionado;	}
	
	//Mesma coisa da classe VeiculoCarga, mas com os atributos da classe VeiculoPasseio
	
	public String toString() 
	{
		return "\n\n [Veiculo Passeio]\n Placa: " + this.getPlaca() + "\n Marca: " + this.getMarca() + "\n Modelo: " + this.getModelo() + "\n Chassi: " + this.getChassi() + 
		"\n Ano: " + this.getAno() + "\n Valor Por KM Rodado: R$ " + (this.getValorKmRodado()) + "\n KM Inicial : " + this.getKmInicial() +"\n KM Final: " + this.getKmFinal() + 
		"\n Valor da Loca��o: R$ " + this.getValorLocacao() +"\n Quantidade de Portas: " + this.qtdPortas +"\n Possui Ar Condicionado: " + this.arCondicionado + "\n [Propriet�rio]" + this.getProprietario();
	}



}
