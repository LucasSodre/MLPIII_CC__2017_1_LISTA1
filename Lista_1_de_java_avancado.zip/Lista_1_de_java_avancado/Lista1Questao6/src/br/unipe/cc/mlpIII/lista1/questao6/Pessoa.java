/*
 * Classe Pessoa que comp�e a Classe Veiculo
 * 
 *  
 *  quest�o 06 da Lista1.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�;
 * 
 */

package br.unipe.cc.mlpIII.lista1.questao6;

public class Pessoa 
{
	//Atributos da Classe Pessoa
	private String nome;
	private int idade;
	private String tipoCarteira;
	//Construtor da classe pessoa
	public Pessoa(String nome, int idade, String carteira)
	{
		this.nome = (nome);
		this.idade = (idade);
		this.tipoCarteira = (carteira);
	}
	
	//Metods get da classe pessoa

	public String getNome() {		return nome;	}
	
	public String getTipoCarteira() {		return tipoCarteira;	}

	public int getIdade() {		return idade;	}
	
	//toString da classe pessoa
	
	public String toString() 
	{
		return "\n Nome: " + this.nome + "\n idade: " + this.idade + "\n Carteira de Motorista: " + this.tipoCarteira;
	}
	
}
