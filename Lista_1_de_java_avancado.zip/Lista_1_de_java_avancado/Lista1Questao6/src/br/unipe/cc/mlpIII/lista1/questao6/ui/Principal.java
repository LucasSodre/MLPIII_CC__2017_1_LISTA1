/*
 * Classe Principal onde � testado as demais classes
 * 
 *  
 *  quest�o 06 da Lista.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�
 * 
 */


package br.unipe.cc.mlpIII.lista1.questao6.ui;
import br.unipe.cc.mlpIII.lista1.questao6.*;

public class Principal 
{
	public static void main(String[] args) //Classe main onde serve apenas para testar as demais classes
	{
		System.out.println("Apenas testa as classes Veiculo,VeiculoCarga,VeiculoPessoal e Pessoa preenchidos com valores quaisquer ");
		
	//Criado um objeto distinto para cada caso
		Pessoa jaoFusc = new Pessoa("Jo�o do Fusca", 48, "AB");
		
		Veiculo fusca = new Veiculo("BTL-7654", "VW", "Fusca", "0000000000000000", 1986, 12.50, 120000, 120806, jaoFusc );
		System.out.println(fusca);
		
		Pessoa zeCamiao = new Pessoa("Z� do Caminh�o", 36 , "E");
		
		VeiculoCarga torqshift = new VeiculoCarga("FTS-6666", "Ford", "Torqshift", "000000000000000000", 2017, 550.90, 0, 2000, "5 Toneladas", zeCamiao); 
		System.out.println(torqshift);
		
		Pessoa rafaelD = new Pessoa ("Rafael D. Car", 26, "B");
		
		VeiculoPasseio palio = new VeiculoPasseio("FDP-0011","Fiat","Palio Flex 1.0","0000000000000000", 2016, 36.50, 0, 126, 4, true, rafaelD);
		
		System.out.println(palio);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}


}
