package br.unipe.cc.mlplll.lista1;

import java.util.Scanner;
/*
 * @alunos:Lucas Camargo Sodré,Aleff Santos da Silva
 */
public class Principal {
	public static void main(String[] args) {
		/*
		 * Menu que testa os gets e setting e o metodo getValorFatura
		 */
		boolean x = true;
		Carro c = new Carro();
		Scanner Entrada = new Scanner(System.in);
		while(x){
			System.out.println("--------------------------");
			System.out.println("Fatura:");
			System.out.println("1-set cor");
			System.out.println("2-set modelo");
			System.out.println("3-set velocidadeAtual");
			System.out.println("4-set velocidadeMaxima");
			System.out.println("5-get cor");
			System.out.println("6-get modelo");
			System.out.println("7-get velocidadeAtual");
			System.out.println("8-get velocidadeMaxima");
			System.out.println("9-ligar");
			System.out.println("10-acelerar");
			System.out.println("11-sair");
			System.out.println("--------------------------");
			String key = Entrada.next();
			switch (key) {
				case "1":
					System.out.println("Digite a cor:");
					String key1 = Entrada.next();
					c.setCor(key1);
					break;
				case "2":
					System.out.println("Digite o modelo:");
					String key2 = Entrada.next();
					c.setModelo(key2);
					break;
				case "3":
					System.out.println("Digite a velocidade atual:");
					int key3 = Entrada.nextInt();
					c.setVelocidadeAtual(key3);
					break;
				case "4":
					System.out.println("Digite a velocidade Maxima:");
					int key4 = Entrada.nextInt();
					c.setVelocidadeAtual(key4);
					break;
				case "5":
					System.out.println("A cor e " + c.getCor());
					break;
				case "6":
					System.out.println("O modelo e " + c.getModelo());
					break;
				case "7":
					System.out.println("A velocidade atual e" + c.getVelocidadeAtual());
					break;
				case "8":
					System.out.println("A velocidade Maxima e " + c.getVelocidadeMaxima());
					break;
				case "9":
					System.out.println("Digite uma velocidade:");
					int key5 = Entrada.nextInt();
					c.ligar(key5);
					break;
				case "10":
					c.acelerar();
					break;
				case "11":
					System.out.println("adeus");
					break;
				default:
					System.out.println("Opição invalida!!");
					break;
			}
		}
	}
}


