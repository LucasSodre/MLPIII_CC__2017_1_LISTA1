package br.unipe.cc.mlplll.lista1;

import java.util.Scanner;

/*
 * @alunos:Lucas Camargo Sodré,Aleff Santos da Silva
 */
public class Principal {
	public static void main(String[] args) {
		/*
		 * Menu que testa os gets e setting e o metodo getValorFatura
		 */
		boolean x = true;
		Fatura f = new Fatura();
		Scanner Entrada = new Scanner(System.in);
		while(x){
			System.out.println("--------------------------");
			System.out.println("Fatura:");
			System.out.println("1-set numero");
			System.out.println("2-set descricao");
			System.out.println("3-set quantidade");
			System.out.println("4-set preco");
			System.out.println("5-get numero");
			System.out.println("6-get descricao");
			System.out.println("7-get quantidade");
			System.out.println("8-get preco");
			System.out.println("9-get Valor da Fatura");
			System.out.println("10-sair");
			System.out.println("--------------------------");
			String key = Entrada.next();
			switch (key) {
				case "1":
					System.out.println("Digite o numero:");
					String key1 = Entrada.next();
					f.setNumero(key1);
					break;
				case "2":
					System.out.println("Digite a descricao:");
					String key2 = Entrada.next();
					f.setDescricao(key2);
					break;
				case "3":
					System.out.println("Digite quantidade:");
					int key3 = Entrada.nextInt();
					f.setQuantidade(key3);
					break;
				case "4":
					System.out.println("Digite preco:");
					double key4 = Entrada.nextDouble();
					f.setPreco(key4);
					break;
				case "5":
					System.out.println("O numero e " + f.getNumero());
					break;
				case "6":
					System.out.println("O numero e " + f.getDescricao());
					break;
				case "7":
					System.out.println("O numero e " + f.getQuantidade());
					break;
				case "8":
					System.out.println("O numero e " + f.getPreco());
					break;
				case "9":
					f.getValorFatura(f.getPreco(), f.getQuantidade());
					break;
				case "10":
					System.out.println("adeus");
					break;
				default:
					break;
			}
		}
	}
}

