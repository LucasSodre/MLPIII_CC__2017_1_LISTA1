package br.unipe.cc.mlplll.lista1;

/*
 * @aluno:Lucas Camargo Sodré,Aleff Santos da Silva
 */
public class Fatura {
	private String numero;
	private String descricao;
	private int quantidade;
	private double preco;
	
	public String getNumero() {
		return numero;
	}
	
	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public int getQuantidade() {
		return quantidade;
	}
	
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	public double getPreco() {
		return preco;
	}
	
	public void setPreco(double preco) {
		this.preco = preco;
	}
	/*
	 * Metodo responsável por retornar o Valor da fatura
	 * @parametro1 : preco
	 * @paremetro2: quantidade
	 *
	 */
	public double getValorFatura(double preco,int quantidade){
		if (preco < 0) {
			return 0.0;
		}
		else{
			if((preco*quantidade) < 0){
				return 0;
			}
			else{
				return preco*quantidade;
			}
		}
		
	}
	
}

