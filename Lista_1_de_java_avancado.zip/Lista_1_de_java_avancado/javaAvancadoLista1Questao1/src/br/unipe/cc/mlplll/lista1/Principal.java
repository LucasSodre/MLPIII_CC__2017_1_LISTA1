package br.unipe.cc.mlplll.lista1;

import java.util.Scanner;

/*
 * @alunos:Lucas Camargo Sodré,Aleff Santos da Silva
 */
public class Principal {
	public static void main(String[] args) {
		/*
		 * Menu que testa os gets e setting e o metodo getValorFatura
		 */
		Professor p = new Professor(null);
		Scanner Entrada = new Scanner(System.in);
		boolean x = true;
		while (x) {
			System.out.println("--------------------------");
			System.out.println("Fatura:");
			System.out.println("1-set cpf");
			System.out.println("2-set matricula");
			System.out.println("3-set nome");
			System.out.println("4-set titulacao");
			System.out.println("5-set especialidade");
			System.out.println("6-get cpf");
			System.out.println("7-get matricula");
			System.out.println("8-get nome");
			System.out.println("9-get titulacao");
			System.out.println("10-get especialidade");
			System.out.println("11-Professor");
			System.out.println("12-sair");
			System.out.println("--------------------------");
			String key = Entrada.next();
			switch (key) {
				case "1":
					System.out.println("Digite o cpf:");
					String key1 = Entrada.next();
					p.setCpf(key1);
					break;
				case "2":
					System.out.println("Digite a matricula:");
					String key2 = Entrada.next();
					p.setMatricula(key2);
					break;
				case "3":
					System.out.println("Digite o nome:");
					String key3 = Entrada.next();
					p.setNome(key3);
					break;
				case "4":
					System.out.println("Digite a titulacao:");
					String key4 = Entrada.next();
					p.setTitulacao(key4);
					break;
				case "5":
					System.out.println("Digite a especialidade:");
					String key5 = Entrada.next();
					p.setEspecialidade(key5);
					break;
				case "6":
					System.out.println("o cpf e " + p.getCpf());
					break;
				case "7":
					System.out.println("o matricula e " + p.getMatricula());
					break;
				case "8":
					System.out.println("o nome e " + p.getNome());
					break;
				case "9":
					System.out.println("o titulacao e " + p.getTitulacao());
					break;
				case "10":
					System.out.println("o especialidade e " + p.getEspecialidade());
					break;		
				case "11":
					System.out.println("Digite o cpf:");
					String t =  Entrada.next();
					System.out.println("Digite a matricula:");
					String t1 =  Entrada.next();
					System.out.println("Digite o nome:");
					String t2 =  Entrada.next();
					break;
				case "12":
					System.out.println("adeus");
					break;
				default:
					System.out.println("Opção invalida!!!");
					break;
				}
		}
	}
}

