package br.unipe.cc.mlplll.lista1;

/*
 * @aluno:Lucas Camargo Sodré,Aleff Santos da Silva
 */
public class Professor {
	private String cpf;
	private String matricula;
	private String nome;
	private String titulacao;
	private String especialidade;
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getTitulacao() {
		return titulacao;
	}
	
	public void setTitulacao(String titulacao) {
		this.titulacao = titulacao;
	}
	
	public String getEspecialidade() {
		return especialidade;
	}
	
	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}
	
	/*
	 * construtor 1
	 * @paarametro1:cpf 
	 * @paarametro2:matricula
	 * @paarametro3:nome
	 */
	public Professor(String cpf,String matricula,String nome){
		this.cpf = cpf;
		this.matricula = matricula;
		this.nome = nome;
	}
	
	/*
	 * construtor 2
	 * @paarametro1:especialidade
	 * @paarametro2:cpf
	 */
	public Professor(String especialidade,String cpf){
		this.especialidade = especialidade;
		this.cpf = cpf;
	}
	
	/*
	 * construtor 3
	 * @paarametro1:titulacao
	 */
	public Professor(String titulacao){
		this.titulacao = titulacao;
	}
	
}

