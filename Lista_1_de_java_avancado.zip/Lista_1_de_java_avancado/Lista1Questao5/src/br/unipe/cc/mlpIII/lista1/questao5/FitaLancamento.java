/*
 * Classe FitaLancamento
 * 
 * quest�o 05 da Lista1.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�
 * 
 */

package br.unipe.cc.mlpIII.lista1.questao5;

public class FitaLancamento extends Fita { //Classe n�o difere em nada da classe pai, exceto pelo pre�oloc que entra com valor modificado

	public FitaLancamento(String titulo, double precoLoc, String categoria, Autor autor) {
		super(titulo, ((precoLoc)+0.40*precoLoc), categoria, autor);
		// TODO Auto-generated constructor stub
	}
	
	public String toString() 
	{
		return "[FITA Lan�amento] Titulo: " + this.getTitulo() + " Pre�o Loca��o: R$ "+ this.getPrecoLoc() +
				" Categoria: " + this.getCategoria() + " " + this.getAutor();
	}

}
