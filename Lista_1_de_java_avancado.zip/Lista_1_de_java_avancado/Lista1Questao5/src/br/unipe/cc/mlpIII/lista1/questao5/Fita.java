/*
 * Classe Fita 
 * 
 * quest�o 05 da Lista1.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�
 * 
 */


package br.unipe.cc.mlpIII.lista1.questao5;
import br.unipe.cc.mlpIII.lista1.questao5.Autor;



public class Fita //Classe fita onde est� todos os atributos usados 
{

	private String titulo;
	private double precoLoc;
	private String categoria;
	private Autor autor;
	
	//m�todos get que serve para serem usados em outras classes
	public String getTitulo()    { return titulo;        }
	public double getPrecoLoc()  { return precoLoc;      }
	public String getCategoria() { return categoria;     }
	public Autor getAutor()      { return autor;         }
	
	public void setAutor(Autor autor) {		this.autor = autor;	}
	
    //Construtor bem simples por sinal
	public Fita(String titulo, double precoLoc, String categoria, Autor autor)
	{
		this.titulo = titulo;
		this.precoLoc = precoLoc;
		this.categoria = categoria;
		this.autor = autor;
	}

	
	
	public String toString() 
	{
		return "[FITA] Titulo: " + this.titulo + " Pre�o Loca��o: R$ "+ this.precoLoc +
				" Categoria: " + this.categoria + " " + this.autor;
	}

	
	
	
}	
