package br.unipe.cc.mlpIII.lista1.questao5.ui;
import java.util.Scanner;
import br.unipe.cc.mlpIII.lista1.questao5.*;
/*
 * Classe Principal 
 * 
 * quest�o 05 da Lista1.
 * 
 * @date 21/02/2017
 * @autor Aleff Santos da Silva and Lucas Camargo Sodr�
 * 
 */
public class Principal {
		//Classe principal que tem o intuito de testar as demais classes do projeto da quest�o5
	//Classes Autor, Fita, FitaInfantil e FitaLancamento.
	

	private static Scanner leitor;

	public static void main(String[] args) {
		String autorNome;
		String autorFilme;
		String fitaNome;
		double fitaPreco;
		String fitaCateg;
		leitor = new Scanner(System.in);
		
		
		System.out.println("_______________________________");
		System.out.println("              FITAS            ");
		System.out.println("_______________________________\n\n");
		System.out.print  (" Informe o Nome da Fita: ");
		fitaNome = leitor.nextLine(); 
		System.out.print  ("\n Informe o pre�o base da Fita em Reais: R$ ");
		fitaPreco = leitor.nextDouble();
		System.out.print  ("\n Informe a categoria do Filme: ");
		fitaCateg = leitor.nextLine();  
		System.out.print  ("\n Informe o Nome do Autor: ");
		autorNome = leitor.nextLine(); 
		System.out.print  ("\n Informe o Filme do Autor: ");
		autorFilme = leitor.nextLine(); 
		
		Autor autor1 = new Autor (autorNome, autorFilme);
	//If que ir� determinar qual fira ser� impressa
		//Se � fita comum, infantil ou Lan�amento.
		char yn = 0;
			System.out.println("O Filme � lan�amento? (Y/N) ");
			yn = leitor.next().charAt(0);
			if(yn ==('Y') || yn ==('y'))
			{
				FitaLancamento fita1 = new FitaLancamento (fitaNome, fitaPreco, fitaCateg, autor1);	
				System.out.println(fita1);
			}
			else 
			{
			System.out.println("O Filme � Infantil? (Y/N) ");
			yn = leitor.next().charAt(0);
			
				if (yn ==('Y') || yn ==('y'))
				{
				FitaInfantil fita1 = new FitaInfantil (fitaNome, fitaPreco, fitaCateg, autor1);
				System.out.println(fita1);
				}else
				{
					Fita fita1 = new Fita (fitaNome, fitaPreco, fitaCateg, autor1);	
					System.out.println(fita1);
				}
			}
	}
}
