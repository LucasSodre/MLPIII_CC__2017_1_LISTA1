package br.unipe.cc.mlpIII.lista1.questao5;

/**
 * 
 * Quest�o 05.
 * 
 * Classe Autor
 * 
 * @author Aleff Santos da Silva And Lucas Camargo Sodr�
 * 
 * 
 * @date 18/02/2017
 */

public class Autor {
	
	private String nome;
	private String filme;
	
	public Autor(String nome, String filme){
		this.nome = nome;
		this.filme = filme;
		
	}
	public String toString() 
	{
		return "[AUTOR] Nome: " + this.nome + " Filme: " + this.filme;
	}

}
